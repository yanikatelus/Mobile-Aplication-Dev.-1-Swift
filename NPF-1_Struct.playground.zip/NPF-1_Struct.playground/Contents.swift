import CoreLocation

struct Park: CustomStringConvertible {
    
    private var parkName: String = ""
    private var parkLocation: String = ""
    private var dateFormed: String = ""
    private var area: String = ""
    private var link: String = ""
    
    private var location : CLLocation?
    private var imageLink : String = ""
    private var parkDescription : String = ""
    
    
    //park name
    func getParkName() -> String{
        parkName
    }
    mutating func setParkName(name: String){
        let trim = name.replacingOccurrences(of: " ", with: "")
        let counter = trim.count
        if (counter >= 3 && counter <= 75 && !trim.isEmpty) {
            parkName = name
        }else{
            parkName = "TBD"
            print("Bad value of \(name) in set(parkName): setting to TBD")
        }
    }
    
    //Park Location
    func getParkLocation() -> String {
        parkLocation
    }
    mutating func setParkLocation(loc: String) {
        let trim = loc.replacingOccurrences(of: " ", with: "")
        let counter = trim.count
        if (counter >= 3 && counter <= 75 && !trim.isEmpty) {
            parkLocation = loc
        }else{
            parkLocation = "TBD"
            print("Bad value of \(loc) in set(parkLocation): setting to TBD")
        }
    }
    
    //date
    func getDateFormed() -> String {
        dateFormed
    }
    mutating func setDateFormed(date: String) {
        dateFormed = date
    }
    
    //area
    func getArea() -> String {
        area
    }
    mutating func setArea(_area: String) {
        area = _area
    }
    
    //link
    func getLink() -> String {
        link
    }
    mutating func setLink(_link: String) {
        link = _link
    }
    
    //location
    func getLocation(){
        location
    }
    mutating func setLocation (_location: CLLocation){
        location = _location
    }
    
    //imageLink
    func getImageLink(){
        imageLink
    }
    mutating func setImageLink(_imageLink: String){
        imageLink = _imageLink
    }
    
    //parkDescription
    func getParkDescription(){
        parkDescription
    }
    mutating func setParkDescription(_parkDescription: String){
        parkDescription = _parkDescription
    }
    
    //description
    var description: String {
        return "{\n parkName: \(parkName)\n parkLocation:\(parkLocation)\n dateFormed:\(dateFormed)\n area:\(area)\n link:\(link)\n location: \(String(describing: location))\n imageLink:\(imageLink)\n parkDescription:\(parkDescription)\n}"
    }

    //Initializers
    init () {
        self.init(parkName: "Unknown", parkLocation: "Unknown", dateFormed: "Unknown", area: "Unknown", link: "Unknown", location: nil, imageLink: "TBD", parkDescription: "TBD" )
    }

    init(parkName: String, parkLocation: String, dateFormed: String, area: String, link: String, location:CLLocation?, imageLink:String,  parkDescription:String){
        self.parkName = parkName
        setParkName(name: parkName)
        
        self.parkLocation = parkLocation
        setParkLocation(loc: parkLocation)
        
        self.dateFormed = dateFormed
        setDateFormed(date: dateFormed)
        
        self.area = area
        setArea(_area: area)
        
        self.link = link
        setLink(_link: link)
        
        self.location = location
        if(location != nil){
            setLocation(_location: location!)
        }
        
        self.imageLink = imageLink
        setImageLink(_imageLink: imageLink)
        
        self.parkDescription = parkDescription
        setParkDescription(_parkDescription: parkDescription)
    }
}//end of class

let p1 : Park = Park()
print("\(p1)")

var p2 : Park = Park(parkName: "Acadia National Park", parkLocation: "Maine", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: " TBD", location: nil, imageLink: "TBD", parkDescription: "TBD" )
print("\(p2)")

p2.setLink(_link: "http://en.wikipedia.org/wiki/Acadia_National_Park")
print("\(p2)")


var p3 = Park(parkName: "ab", parkLocation: "na", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD")
print("\(p3)")
