let tutorialTeam: Int = 56
let editorialTeam = 23
var totalTeam = tutorialTeam + editorialTeam
totalTeam += 1

let price = 19.99
let onSale = true

let name =  "Slinky"
let name2 = """
            line 1
        line 2
            Line 3
        """
if onSale{
    print("\(name) on sale for \(price)")
}else{
    print("\(name) not on sale for \(price)")
}

print("a", terminator: ",")
print("b")

