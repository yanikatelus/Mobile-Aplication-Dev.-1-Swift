
class tipCalculator {
    // create class by using class and name with {}
    //classes do not inherit from common class
    let total: Double
    let taxPct: Double
    let subTotal: Double
    
    init(total: Double, taxPct:Double){
        self.total = total
        self.taxPct = taxPct
        subTotal = total/(taxPct + 1)
    }
    
    func calcTipWith(tipPct:Double) -> Double {
        subTotal * tipPct
    }
    
//    func printPossibleTips(){
////        print("15%: \(calcTipWith (tipPct: 0.15))")
////        print("18%: \(calcTipWith (tipPct: 0.18))")
////        print("20%: \(calcTipWith (tipPct: 0.20))")
//        let possibleTips = [0.15,0.18,0.20]
//
//        for possibleTips in possibleTips{
//            print("\(possibleTip * 100))%: \(calcTipWith(tipPct: possibleTips))")
//        }
//    }
    
    func returnPossibleTips() -> [Int: Double]{
        let possibleTips = [0.15,0.18,0.20]
        var retVal = Dictionary<Int,Double>() // or [Int:Double]()
        
        for possibleTips in possibleTips{
            let intPct = Int(possibleTip * 100)
            retVal[intPct] = calcTipWith(tipPct: possibleTips)
        }
        return retVal
        
    }
    
}//class
//creating an instance of our class
let tipCalc = tipCalculator(total: 33.25, taxPct: 0.06)
//tipCalc.printPossibleTips()
tipCalc.returnPossibleTips()
